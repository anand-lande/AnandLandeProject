package com.divinehospital.Divine.Dental.Care.Hospital;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;




@Controller
public class ClinicController {
	
	@Autowired
	SessionFactory sf;
	
	@RequestMapping("loginpage")
	public String name() {
		return "login";
	}

	@RequestMapping("/login")
	public String Login(Login login, Model model) {
		
		Session session = sf.openSession();

		Login dbLogin = session.get(Login.class, login.getUsername()); 

		String page = "login";
		String msg = null;
		if (dbLogin != null) {
			if (login.getUsername().equals(dbLogin.getUsername())) { 
				page = "home";
			} else {
				msg = "Invalid Username";
			}
		} else {
			msg = "Invalid Password";
		}
		model.addAttribute("msg", msg); 
		return page;
		
		
	}

	@RequestMapping("/createaccountpage")
	public String createaccountpage() {
		return "createaccount";
	}

	
	@RequestMapping("/createaccount")
	public Login createaccount(Login login) {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		ss.save(login);
		System.out.println(login);
		tx.commit();
		return login;
		
	}
	
	@RequestMapping("homepage")
	String home() {
		return "home";
	}

	@RequestMapping("aboutpage")
	String about() {
		return "about";
	}
	@RequestMapping("contactpage")
	String contact() {
		return "contact";
	}
	
	@RequestMapping("contact")
	public Contact contactsave(Contact contact) {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		ss.save(contact);
		System.out.println(contact);
		tx.commit();
		return contact;
	}

	@RequestMapping("pricepage")
	String price() {
		return "price";
	}

	@RequestMapping("servicepage")
	String service() {
		return "service";
	}
	@RequestMapping("teampage")
	String team() {
		return "team";
	}

	@RequestMapping("testimonialpage")
	String testimonial() {
		return "testimonial";
	}
	@RequestMapping("appointmentpage")
	String appointment() {
		return "appointment";
	}
	
	
	@RequestMapping("/appointment")
	public Appointment appointmentSave(Appointment appointment) {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		ss.save(appointment);
		System.out.println(appointment);
		tx.commit();
		return appointment;
	}
}

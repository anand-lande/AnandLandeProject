package com.divinehospital.Divine.Dental.Care.Hospital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DivineDentalCareHospitalApplicationTests {

	@Test
	void contextLoads() {
	}

}

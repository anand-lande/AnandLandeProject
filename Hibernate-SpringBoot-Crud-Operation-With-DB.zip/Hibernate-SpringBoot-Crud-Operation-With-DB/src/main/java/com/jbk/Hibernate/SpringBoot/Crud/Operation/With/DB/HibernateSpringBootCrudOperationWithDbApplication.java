package com.jbk.Hibernate.SpringBoot.Crud.Operation.With.DB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernateSpringBootCrudOperationWithDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibernateSpringBootCrudOperationWithDbApplication.class, args);
		System.out.println("SpringBoot Integration");
	}

}

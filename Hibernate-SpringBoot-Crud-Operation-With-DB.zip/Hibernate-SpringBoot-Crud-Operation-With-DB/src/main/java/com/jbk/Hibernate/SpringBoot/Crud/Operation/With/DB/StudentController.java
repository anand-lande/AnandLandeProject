package com.jbk.Hibernate.SpringBoot.Crud.Operation.With.DB;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {

	@Autowired
	SessionFactory sf;
	
	@RequestMapping("single")
	public Student singleRecord() {
		Session ss = sf.openSession();
		Student s = ss.get(Student.class, 101);
		return s;
	}
	
	@RequestMapping("insert")
	public Student insert() {
		
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		Student s = new Student(102, "anand");

		ss.save(s);

		System.out.println(s);

		tx.commit();
		
		return s;

	}
	
	@RequestMapping("update")
	public Student update() {
		
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		Student s = new Student(101, "Anand");

		ss.update(s);

		System.out.println(s);

		tx.commit();
		
		return s;

	}
	
	// Non Parameter
	// parameter -> @PathVariable/@RequestBody
	
	@RequestMapping("delete")
	public Student delete() {
		
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		Student s = new Student(101, "Gopal");

		ss.delete(s);

		System.out.println(s);

		tx.commit();
		
		return s;

	}
	
}

package com.jbk.Hibernate.SpringBoot.Crud.Operation.With.DB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateSpringBootCrudOperationWithDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
